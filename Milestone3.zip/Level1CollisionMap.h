
//{{BLOCK(Level1CollisionMap)

//======================================================================
//
//	Level1CollisionMap, 2799x256@16, 
//	+ bitmap not compressed
//	Total size: 1433600 = 1433600
//
//	Time-stamp: 2020-11-14, 23:15:32
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL1COLLISIONMAP_H
#define GRIT_LEVEL1COLLISIONMAP_H

#define Level1CollisionMapBitmapLen 1433600
extern const unsigned short Level1CollisionMapBitmap[716800];

#endif // GRIT_LEVEL1COLLISIONMAP_H

//}}BLOCK(Level1CollisionMap)
