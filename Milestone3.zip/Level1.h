
//{{BLOCK(Level1)

//======================================================================
//
//	Level1, 2816x256@4, 
//	+ palette 256 entries, not compressed
//	+ 535 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 352x32 
//	Total size: 512 + 17120 + 22528 = 40160
//
//	Time-stamp: 2020-11-14, 23:01:41
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL1_H
#define GRIT_LEVEL1_H

#define Level1TilesLen 17120
extern const unsigned short Level1Tiles[8560];

#define Level1MapLen 22528
extern const unsigned short Level1Map[11264];

#define Level1PalLen 512
extern const unsigned short Level1Pal[256];

#endif // GRIT_LEVEL1_H

//}}BLOCK(Level1)
