void updateGame();
void updatePlayer();
void drawGame();
void initializeGame();
void initializeBackground();