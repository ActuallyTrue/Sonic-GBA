
//{{BLOCK(testcollisionmap)

//======================================================================
//
//	testcollisionmap, 240x160@16, 
//	+ bitmap not compressed
//	Total size: 76800 = 76800
//
//	Time-stamp: 2020-11-01, 17:08:30
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_TESTCOLLISIONMAP_H
#define GRIT_TESTCOLLISIONMAP_H

#define testcollisionmapBitmapLen 76800
extern const unsigned short testcollisionmapBitmap[38400];

#endif // GRIT_TESTCOLLISIONMAP_H

//}}BLOCK(testcollisionmap)
