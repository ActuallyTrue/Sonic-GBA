
//{{BLOCK(sonicSprite)

//======================================================================
//
//	sonicSprite, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 1024 tiles not compressed
//	Total size: 512 + 32768 = 33280
//
//	Time-stamp: 2020-11-01, 15:49:26
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SONICSPRITE_H
#define GRIT_SONICSPRITE_H

#define sonicSpriteTilesLen 32768
extern const unsigned short sonicSpriteTiles[16384];

#define sonicSpritePalLen 512
extern const unsigned short sonicSpritePal[256];

#endif // GRIT_SONICSPRITE_H

//}}BLOCK(sonicSprite)
