// pauseSound sound made by wav2c

extern const unsigned int pauseSound_sampleRate;
extern const unsigned int pauseSound_length;
extern const signed char pauseSound_data[];
