// titleSong sound made by wav2c

extern const unsigned int titleSong_sampleRate;
extern const unsigned int titleSong_length;
extern const signed char titleSong_data[];
