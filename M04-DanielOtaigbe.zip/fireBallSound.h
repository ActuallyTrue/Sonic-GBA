// fireBallSound sound made by wav2c

extern const unsigned int fireBallSound_sampleRate;
extern const unsigned int fireBallSound_length;
extern const signed char fireBallSound_data[];
