// itemSpawnSound sound made by wav2c

extern const unsigned int itemSpawnSound_sampleRate;
extern const unsigned int itemSpawnSound_length;
extern const signed char itemSpawnSound_data[];
