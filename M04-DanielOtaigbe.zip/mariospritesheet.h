
//{{BLOCK(mariospritesheet)

//======================================================================
//
//	mariospritesheet, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 1024 tiles not compressed
//	Total size: 512 + 32768 = 33280
//
//	Time-stamp: 2020-11-24, 11:34:40
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_MARIOSPRITESHEET_H
#define GRIT_MARIOSPRITESHEET_H

#define mariospritesheetTilesLen 32768
extern const unsigned short mariospritesheetTiles[16384];

#define mariospritesheetPalLen 512
extern const unsigned short mariospritesheetPal[256];

#endif // GRIT_MARIOSPRITESHEET_H

//}}BLOCK(mariospritesheet)
