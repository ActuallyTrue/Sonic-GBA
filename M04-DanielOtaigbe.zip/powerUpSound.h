// powerUpSound sound made by wav2c

extern const unsigned int powerUpSound_sampleRate;
extern const unsigned int powerUpSound_length;
extern const signed char powerUpSound_data[];
