
//{{BLOCK(Level1CollisionMap)

//======================================================================
//
//	Level1CollisionMap, 2816x256@16, 
//	+ bitmap not compressed
//	Total size: 1441792 = 1441792
//
//	Time-stamp: 2020-11-23, 22:51:00
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_LEVEL1COLLISIONMAP_H
#define GRIT_LEVEL1COLLISIONMAP_H

#define Level1CollisionMapBitmapLen 1441792
extern const unsigned short Level1CollisionMapBitmap[720896];

#endif // GRIT_LEVEL1COLLISIONMAP_H

//}}BLOCK(Level1CollisionMap)
