// powerDownSound sound made by wav2c

extern const unsigned int powerDownSound_sampleRate;
extern const unsigned int powerDownSound_length;
extern const signed char powerDownSound_data[];
