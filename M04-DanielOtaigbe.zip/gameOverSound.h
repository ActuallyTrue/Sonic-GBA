// gameOverSound sound made by wav2c

extern const unsigned int gameOverSound_sampleRate;
extern const unsigned int gameOverSound_length;
extern const signed char gameOverSound_data[];
