// coinSound sound made by wav2c

extern const unsigned int coinSound_sampleRate;
extern const unsigned int coinSound_length;
extern const signed char coinSound_data[];
